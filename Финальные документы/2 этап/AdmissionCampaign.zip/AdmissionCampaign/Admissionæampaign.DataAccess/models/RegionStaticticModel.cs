﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdmissionCampaign.DataAccess.models
{
    public class RegionStaticticModel
    {
        public string Region { get; set; }
        public int Count { get; set; }
    }
}
